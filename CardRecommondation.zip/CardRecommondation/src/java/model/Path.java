/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Zhirun Tian
 */
public class Path {

    public static String DataDir = "C:\\Users\\Zhirun Tian\\Documents\\GitHub\\CardRecommondation\\data\\docset";//address of docset.trectext
    public static String IndexDir = "c://study/index/testindex";//address of generated Web index file

}
